using System;
using System.Windows.Forms;
using BoletinCalificaciones;

namespace boletin_de_calificaciones
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new Form1());
        }
    }
}