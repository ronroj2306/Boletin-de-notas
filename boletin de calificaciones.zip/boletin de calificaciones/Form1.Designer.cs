﻿namespace BoletinCalificaciones
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.grpEstudiante = new System.Windows.Forms.GroupBox();
            this.rdbVespertina = new System.Windows.Forms.RadioButton();
            this.rdbMatutina = new System.Windows.Forms.RadioButton();
            this.lblTanda = new System.Windows.Forms.Label();
            this.txtEstudiante = new System.Windows.Forms.TextBox();
            this.lblNombre = new System.Windows.Forms.Label();
            this.grpAsignatura = new System.Windows.Forms.GroupBox();
            this.btnRegistrar = new System.Windows.Forms.Button();
            this.chkAsistencia = new System.Windows.Forms.CheckBox();
            this.txtP4 = new System.Windows.Forms.TextBox();
            this.txtP3 = new System.Windows.Forms.TextBox();
            this.txtP2 = new System.Windows.Forms.TextBox();
            this.txtP1 = new System.Windows.Forms.TextBox();
            this.lblP4 = new System.Windows.Forms.Label();
            this.lblP3 = new System.Windows.Forms.Label();
            this.lblP2 = new System.Windows.Forms.Label();
            this.lblP1 = new System.Windows.Forms.Label();
            this.lblCalificaciones = new System.Windows.Forms.Label();
            this.cmbAsignatura = new System.Windows.Forms.ComboBox();
            this.lblAsignatura = new System.Windows.Forms.Label();
            this.grpBoletin = new System.Windows.Forms.GroupBox();
            this.lstBoletin = new System.Windows.Forms.ListBox();
            this.grpResumen = new System.Windows.Forms.GroupBox();
            this.lblSituacion = new System.Windows.Forms.Label();
            this.lblReprobadas = new System.Windows.Forms.Label();
            this.lblRecuperacion = new System.Windows.Forms.Label();
            this.lblAprobadas = new System.Windows.Forms.Label();
            this.lblPromedioGeneral = new System.Windows.Forms.Label();
            this.lblTitReprobadas = new System.Windows.Forms.Label();
            this.lblTitRecuperacion = new System.Windows.Forms.Label();
            this.lblTitAprobadas = new System.Windows.Forms.Label();
            this.lblTitPromedio = new System.Windows.Forms.Label();
            this.btnResumen = new System.Windows.Forms.Button();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.btnSalir = new System.Windows.Forms.Button();
            this.grpEstudiante.SuspendLayout();
            this.grpAsignatura.SuspendLayout();
            this.grpBoletin.SuspendLayout();
            this.grpResumen.SuspendLayout();
            this.SuspendLayout();

            // grpEstudiante
            this.grpEstudiante.Controls.Add(this.rdbVespertina);
            this.grpEstudiante.Controls.Add(this.rdbMatutina);
            this.grpEstudiante.Controls.Add(this.lblTanda);
            this.grpEstudiante.Controls.Add(this.txtEstudiante);
            this.grpEstudiante.Controls.Add(this.lblNombre);
            this.grpEstudiante.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.grpEstudiante.Location = new System.Drawing.Point(16, 15);
            this.grpEstudiante.Name = "grpEstudiante";
            this.grpEstudiante.Size = new System.Drawing.Size(340, 115);
            this.grpEstudiante.TabIndex = 0;
            this.grpEstudiante.TabStop = false;
            this.grpEstudiante.Text = "Datos del estudiante";

            // lblNombre
            this.lblNombre.AutoSize = true;
            this.lblNombre.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNombre.Location = new System.Drawing.Point(14, 32);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(58, 17);
            this.lblNombre.Text = "Nombre:";

            // txtEstudiante
            this.txtEstudiante.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtEstudiante.Location = new System.Drawing.Point(85, 29);
            this.txtEstudiante.Name = "txtEstudiante";
            this.txtEstudiante.Size = new System.Drawing.Size(235, 24);
            this.txtEstudiante.TabIndex = 1;

            // lblTanda
            this.lblTanda.AutoSize = true;
            this.lblTanda.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblTanda.Location = new System.Drawing.Point(14, 72);
            this.lblTanda.Name = "lblTanda";
            this.lblTanda.Size = new System.Drawing.Size(46, 17);
            this.lblTanda.Text = "Tanda:";

            // rdbMatutina
            this.rdbMatutina.AutoSize = true;
            this.rdbMatutina.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.rdbMatutina.Location = new System.Drawing.Point(85, 70);
            this.rdbMatutina.Name = "rdbMatutina";
            this.rdbMatutina.Size = new System.Drawing.Size(81, 21);
            this.rdbMatutina.TabIndex = 2;
            this.rdbMatutina.Text = "Matutina";
            this.rdbMatutina.UseVisualStyleBackColor = true;

            // rdbVespertina
            this.rdbVespertina.AutoSize = true;
            this.rdbVespertina.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.rdbVespertina.Location = new System.Drawing.Point(185, 70);
            this.rdbVespertina.Name = "rdbVespertina";
            this.rdbVespertina.Size = new System.Drawing.Size(87, 21);
            this.rdbVespertina.TabIndex = 3;
            this.rdbVespertina.Text = "Vespertina";
            this.rdbVespertina.UseVisualStyleBackColor = true;

            // grpAsignatura
            this.grpAsignatura.Controls.Add(this.btnRegistrar);
            this.grpAsignatura.Controls.Add(this.chkAsistencia);
            this.grpAsignatura.Controls.Add(this.txtP4);
            this.grpAsignatura.Controls.Add(this.txtP3);
            this.grpAsignatura.Controls.Add(this.txtP2);
            this.grpAsignatura.Controls.Add(this.txtP1);
            this.grpAsignatura.Controls.Add(this.lblP4);
            this.grpAsignatura.Controls.Add(this.lblP3);
            this.grpAsignatura.Controls.Add(this.lblP2);
            this.grpAsignatura.Controls.Add(this.lblP1);
            this.grpAsignatura.Controls.Add(this.lblCalificaciones);
            this.grpAsignatura.Controls.Add(this.cmbAsignatura);
            this.grpAsignatura.Controls.Add(this.lblAsignatura);
            this.grpAsignatura.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.grpAsignatura.Location = new System.Drawing.Point(16, 140);
            this.grpAsignatura.Name = "grpAsignatura";
            this.grpAsignatura.Size = new System.Drawing.Size(340, 235);
            this.grpAsignatura.TabIndex = 1;
            this.grpAsignatura.TabStop = false;
            this.grpAsignatura.Text = "Registro de asignatura";

            // lblAsignatura
            this.lblAsignatura.AutoSize = true;
            this.lblAsignatura.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblAsignatura.Location = new System.Drawing.Point(14, 32);
            this.lblAsignatura.Name = "lblAsignatura";
            this.lblAsignatura.Size = new System.Drawing.Size(74, 17);
            this.lblAsignatura.Text = "Asignatura:";

            // cmbAsignatura
            this.cmbAsignatura.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAsignatura.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.cmbAsignatura.FormattingEnabled = true;
            this.cmbAsignatura.Location = new System.Drawing.Point(95, 29);
            this.cmbAsignatura.Name = "cmbAsignatura";
            this.cmbAsignatura.Size = new System.Drawing.Size(225, 25);
            this.cmbAsignatura.TabIndex = 1;

            // lblCalificaciones
            this.lblCalificaciones.AutoSize = true;
            this.lblCalificaciones.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblCalificaciones.Location = new System.Drawing.Point(14, 70);
            this.lblCalificaciones.Name = "lblCalificaciones";
            this.lblCalificaciones.Size = new System.Drawing.Size(208, 17);
            this.lblCalificaciones.Text = "Calificaciones por período (0 a 100):";

            // lblP1 - lblP4
            this.lblP1.AutoSize = true;
            this.lblP1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblP1.Location = new System.Drawing.Point(35, 95);
            this.lblP1.Name = "lblP1";
            this.lblP1.Size = new System.Drawing.Size(21, 15);
            this.lblP1.Text = "P1";

            this.lblP2.AutoSize = true;
            this.lblP2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblP2.Location = new System.Drawing.Point(113, 95);
            this.lblP2.Name = "lblP2";
            this.lblP2.Size = new System.Drawing.Size(21, 15);
            this.lblP2.Text = "P2";

            this.lblP3.AutoSize = true;
            this.lblP3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblP3.Location = new System.Drawing.Point(191, 95);
            this.lblP3.Name = "lblP3";
            this.lblP3.Size = new System.Drawing.Size(21, 15);
            this.lblP3.Text = "P3";

            this.lblP4.AutoSize = true;
            this.lblP4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblP4.Location = new System.Drawing.Point(269, 95);
            this.lblP4.Name = "lblP4";
            this.lblP4.Size = new System.Drawing.Size(21, 15);
            this.lblP4.Text = "P4";

            // txtP1 - txtP4
            this.txtP1.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtP1.Location = new System.Drawing.Point(14, 114);
            this.txtP1.Name = "txtP1";
            this.txtP1.Size = new System.Drawing.Size(68, 24);
            this.txtP1.TabIndex = 2;
            this.txtP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;

            this.txtP2.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtP2.Location = new System.Drawing.Point(92, 114);
            this.txtP2.Name = "txtP2";
            this.txtP2.Size = new System.Drawing.Size(68, 24);
            this.txtP2.TabIndex = 3;
            this.txtP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;

            this.txtP3.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtP3.Location = new System.Drawing.Point(170, 114);
            this.txtP3.Name = "txtP3";
            this.txtP3.Size = new System.Drawing.Size(68, 24);
            this.txtP3.TabIndex = 4;
            this.txtP3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;

            this.txtP4.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtP4.Location = new System.Drawing.Point(248, 114);
            this.txtP4.Name = "txtP4";
            this.txtP4.Size = new System.Drawing.Size(68, 24);
            this.txtP4.TabIndex = 5;
            this.txtP4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;

            // chkAsistencia
            this.chkAsistencia.AutoSize = true;
            this.chkAsistencia.Checked = true;
            this.chkAsistencia.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkAsistencia.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.chkAsistencia.Location = new System.Drawing.Point(14, 152);
            this.chkAsistencia.Name = "chkAsistencia";
            this.chkAsistencia.Size = new System.Drawing.Size(222, 21);
            this.chkAsistencia.TabIndex = 6;
            this.chkAsistencia.Text = "Cumple la asistencia mínima (80 %)";
            this.chkAsistencia.UseVisualStyleBackColor = true;

            // btnRegistrar
            this.btnRegistrar.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnRegistrar.Location = new System.Drawing.Point(14, 184);
            this.btnRegistrar.Name = "btnRegistrar";
            this.btnRegistrar.Size = new System.Drawing.Size(306, 35);
            this.btnRegistrar.TabIndex = 7;
            this.btnRegistrar.Text = "Registrar asignatura";
            this.btnRegistrar.UseVisualStyleBackColor = true;
            this.btnRegistrar.Click += new System.EventHandler(this.btnRegistrar_Click);

            // grpBoletin
            this.grpBoletin.Controls.Add(this.lstBoletin);
            this.grpBoletin.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.grpBoletin.Location = new System.Drawing.Point(372, 15);
            this.grpBoletin.Name = "grpBoletin";
            this.grpBoletin.Size = new System.Drawing.Size(330, 185);
            this.grpBoletin.TabIndex = 2;
            this.grpBoletin.TabStop = false;
            this.grpBoletin.Text = "Boletín del estudiante";

            // lstBoletin
            this.lstBoletin.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lstBoletin.FormattingEnabled = true;
            this.lstBoletin.ItemHeight = 17;
            this.lstBoletin.Location = new System.Drawing.Point(14, 26);
            this.lstBoletin.Name = "lstBoletin";
            this.lstBoletin.Size = new System.Drawing.Size(302, 140);
            this.lstBoletin.TabIndex = 0;

            // grpResumen
            this.grpResumen.Controls.Add(this.lblSituacion);
            this.grpResumen.Controls.Add(this.lblReprobadas);
            this.grpResumen.Controls.Add(this.lblRecuperacion);
            this.grpResumen.Controls.Add(this.lblAprobadas);
            this.grpResumen.Controls.Add(this.lblPromedioGeneral);
            this.grpResumen.Controls.Add(this.lblTitReprobadas);
            this.grpResumen.Controls.Add(this.lblTitRecuperacion);
            this.grpResumen.Controls.Add(this.lblTitAprobadas);
            this.grpResumen.Controls.Add(this.lblTitPromedio);
            this.grpResumen.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.grpResumen.Location = new System.Drawing.Point(372, 210);
            this.grpResumen.Name = "grpResumen";
            this.grpResumen.Size = new System.Drawing.Size(330, 165);
            this.grpResumen.TabIndex = 3;
            this.grpResumen.TabStop = false;
            this.grpResumen.Text = "Resumen";

            // Etiquetas fijas del resumen
            this.lblTitPromedio.AutoSize = true;
            this.lblTitPromedio.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblTitPromedio.Location = new System.Drawing.Point(14, 28);
            this.lblTitPromedio.Text = "Promedio general:";

            this.lblTitAprobadas.AutoSize = true;
            this.lblTitAprobadas.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblTitAprobadas.Location = new System.Drawing.Point(14, 54);
            this.lblTitAprobadas.Text = "Aprobadas:";

            this.lblTitRecuperacion.AutoSize = true;
            this.lblTitRecuperacion.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblTitRecuperacion.Location = new System.Drawing.Point(14, 80);
            this.lblTitRecuperacion.Text = "En recuperación:";

            this.lblTitReprobadas.AutoSize = true;
            this.lblTitReprobadas.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblTitReprobadas.Location = new System.Drawing.Point(14, 106);
            this.lblTitReprobadas.Text = "Reprobadas:";

            // Etiquetas dinámicas del resumen
            this.lblPromedioGeneral.AutoSize = true;
            this.lblPromedioGeneral.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.lblPromedioGeneral.Location = new System.Drawing.Point(250, 28);
            this.lblPromedioGeneral.Name = "lblPromedioGeneral";
            this.lblPromedioGeneral.Text = "0.00";

            this.lblAprobadas.AutoSize = true;
            this.lblAprobadas.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.lblAprobadas.Location = new System.Drawing.Point(250, 54);
            this.lblAprobadas.Name = "lblAprobadas";
            this.lblAprobadas.Text = "0";

            this.lblRecuperacion.AutoSize = true;
            this.lblRecuperacion.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.lblRecuperacion.Location = new System.Drawing.Point(250, 80);
            this.lblRecuperacion.Name = "lblRecuperacion";
            this.lblRecuperacion.Text = "0";

            this.lblReprobadas.AutoSize = true;
            this.lblReprobadas.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.lblReprobadas.Location = new System.Drawing.Point(250, 106);
            this.lblReprobadas.Name = "lblReprobadas";
            this.lblReprobadas.Text = "0";

            this.lblSituacion.AutoSize = true;
            this.lblSituacion.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.lblSituacion.Location = new System.Drawing.Point(14, 134);
            this.lblSituacion.Name = "lblSituacion";
            this.lblSituacion.Text = "Situación: -";

            // Botones inferiores
            this.btnResumen.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnResumen.Location = new System.Drawing.Point(16, 390);
            this.btnResumen.Name = "btnResumen";
            this.btnResumen.Size = new System.Drawing.Size(215, 36);
            this.btnResumen.TabIndex = 4;
            this.btnResumen.Text = "Mostrar resumen";
            this.btnResumen.UseVisualStyleBackColor = true;
            this.btnResumen.Click += new System.EventHandler(this.btnResumen_Click);

            this.btnLimpiar.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnLimpiar.Location = new System.Drawing.Point(251, 390);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(215, 36);
            this.btnLimpiar.TabIndex = 5;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);

            this.btnSalir.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnSalir.Location = new System.Drawing.Point(487, 390);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(215, 36);
            this.btnSalir.TabIndex = 6;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);

            // Form1
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(718, 442);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.btnLimpiar);
            this.Controls.Add(this.btnResumen);
            this.Controls.Add(this.grpResumen);
            this.Controls.Add(this.grpBoletin);
            this.Controls.Add(this.grpAsignatura);
            this.Controls.Add(this.grpEstudiante);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Boletín de Calificaciones";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grpEstudiante.ResumeLayout(false);
            this.grpEstudiante.PerformLayout();
            this.grpAsignatura.ResumeLayout(false);
            this.grpAsignatura.PerformLayout();
            this.grpBoletin.ResumeLayout(false);
            this.grpResumen.ResumeLayout(false);
            this.grpResumen.PerformLayout();
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.GroupBox grpEstudiante;
        private System.Windows.Forms.RadioButton rdbVespertina;
        private System.Windows.Forms.RadioButton rdbMatutina;
        private System.Windows.Forms.Label lblTanda;
        private System.Windows.Forms.TextBox txtEstudiante;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.GroupBox grpAsignatura;
        private System.Windows.Forms.Button btnRegistrar;
        private System.Windows.Forms.CheckBox chkAsistencia;
        private System.Windows.Forms.TextBox txtP4;
        private System.Windows.Forms.TextBox txtP3;
        private System.Windows.Forms.TextBox txtP2;
        private System.Windows.Forms.TextBox txtP1;
        private System.Windows.Forms.Label lblP4;
        private System.Windows.Forms.Label lblP3;
        private System.Windows.Forms.Label lblP2;
        private System.Windows.Forms.Label lblP1;
        private System.Windows.Forms.Label lblCalificaciones;
        private System.Windows.Forms.ComboBox cmbAsignatura;
        private System.Windows.Forms.Label lblAsignatura;
        private System.Windows.Forms.GroupBox grpBoletin;
        private System.Windows.Forms.ListBox lstBoletin;
        private System.Windows.Forms.GroupBox grpResumen;
        private System.Windows.Forms.Label lblSituacion;
        private System.Windows.Forms.Label lblReprobadas;
        private System.Windows.Forms.Label lblRecuperacion;
        private System.Windows.Forms.Label lblAprobadas;
        private System.Windows.Forms.Label lblPromedioGeneral;
        private System.Windows.Forms.Label lblTitReprobadas;
        private System.Windows.Forms.Label lblTitRecuperacion;
        private System.Windows.Forms.Label lblTitAprobadas;
        private System.Windows.Forms.Label lblTitPromedio;
        private System.Windows.Forms.Button btnResumen;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.Button btnSalir;
    }
}