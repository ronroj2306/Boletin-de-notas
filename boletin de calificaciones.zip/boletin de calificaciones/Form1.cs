using System;
using System.Windows.Forms;

namespace BoletinCalificaciones
{
    public partial class Form1 : Form
    {
        // Constantes definidas para las reglas de evaluación
        private const double MINIMO_APROBACION = 70.0;
        private const double MINIMO_RECUPERACION = 60.0;
        private const int TOTAL_PERIODOS = 4;

        // Acumuladores y contadores globales del formulario
        private double acumuladorPromedios = 0.0;
        private int contadorMaterias = 0;
        private int materiasAprobadas = 0;
        private int materiasRecuperacion = 0;
        private int materiasReprobadas = 0;

        public Form1()
        {
            InitializeComponent();
        }

        // Evento Load: carga el listado inicial de asignaturas y prepara los controles
        private void Form1_Load(object sender, EventArgs e)
        {
            string[] materias = { "Matemática", "Lengua Española", "Ciencias Naturales", "Inglés", "Informática" };
            cmbAsignatura.Items.Clear();
            cmbAsignatura.Items.AddRange(materias);

            ReiniciarControles();
        }

        // Evento Click de btnRegistrar: comprueba los campos, calcula el promedio y registra la materia
        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            if (txtEstudiante.Text.Trim() == "")
            {
                MessageBox.Show("Por favor, escriba el nombre completo del estudiante.", "Dato requerido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtEstudiante.Focus();
                return;
            }

            if (!rdbMatutina.Checked && !rdbVespertina.Checked)
            {
                MessageBox.Show("Por favor, elija la tanda del estudiante.", "Dato requerido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (cmbAsignatura.SelectedIndex < 0)
            {
                MessageBox.Show("Por favor, seleccione una asignatura de la lista.", "Dato requerido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cmbAsignatura.Focus();
                return;
            }

            // Conversión y validación de rango (0 a 100) para los 4 períodos
            double nota1, nota2, nota3, nota4;
            bool p1Valido = double.TryParse(txtP1.Text, out nota1) && nota1 >= 0 && nota1 <= 100;
            bool p2Valido = double.TryParse(txtP2.Text, out nota2) && nota2 >= 0 && nota2 <= 100;
            bool p3Valido = double.TryParse(txtP3.Text, out nota3) && nota3 >= 0 && nota3 <= 100;
            bool p4Valido = double.TryParse(txtP4.Text, out nota4) && nota4 >= 0 && nota4 <= 100;

            if (!p1Valido || !p2Valido || !p3Valido || !p4Valido)
            {
                MessageBox.Show("Todas las calificaciones deben ser números válidos entre 0 y 100.", "Error de calificación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Cálculo del promedio final de la asignatura
            double promedioMateria = (nota1 + nota2 + nota3 + nota4) / TOTAL_PERIODOS;
            string estadoMateria;

            // Evaluación condicional de asistencia y calificación
            if (!chkAsistencia.Checked)
            {
                estadoMateria = "Reprobada por asistencia";
                materiasReprobadas++;
            }
            else if (promedioMateria >= MINIMO_APROBACION)
            {
                estadoMateria = "Aprobada";
                materiasAprobadas++;
            }
            else if (promedioMateria >= MINIMO_RECUPERACION)
            {
                estadoMateria = "En recuperación";
                materiasRecuperacion++;
            }
            else
            {
                estadoMateria = "Reprobada";
                materiasReprobadas++;
            }

            // Actualización de acumuladores y registro visual en el boletín
            acumuladorPromedios += promedioMateria;
            contadorMaterias++;

            lstBoletin.Items.Add(string.Format("{0} · {1:0.00} · {2}", cmbAsignatura.Text, promedioMateria, estadoMateria));

            // Preparar campos para ingresar otra asignatura
            cmbAsignatura.SelectedIndex = -1;
            txtP1.Text = string.Empty;
            txtP2.Text = string.Empty;
            txtP3.Text = string.Empty;
            txtP4.Text = string.Empty;
            chkAsistencia.Checked = true;
            cmbAsignatura.Focus();
        }

        // Evento Click de btnResumen: muestra el promedio general y el estado académico global
        private void btnResumen_Click(object sender, EventArgs e)
        {
            if (contadorMaterias == 0)
            {
                MessageBox.Show("Aún no se ha registrado ninguna asignatura en el boletín.", "Boletín vacío", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            double promedioFinal = acumuladorPromedios / contadorMaterias;

            lblPromedioGeneral.Text = promedioFinal.ToString("0.00");
            lblAprobadas.Text = materiasAprobadas.ToString();
            lblRecuperacion.Text = materiasRecuperacion.ToString();
            lblReprobadas.Text = materiasReprobadas.ToString();

            if (materiasReprobadas > 0)
            {
                lblSituacion.Text = "Situación: Tiene asignaturas reprobadas";
            }
            else if (materiasRecuperacion > 0)
            {
                lblSituacion.Text = "Situación: Tiene asignaturas en recuperación";
            }
            else
            {
                lblSituacion.Text = "Situación: Aprobó todas las asignaturas";
            }
        }

        // Evento Click de btnLimpiar: devuelve el formulario a su estado original
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            ReiniciarControles();
        }

        // Evento Click de btnSalir: finaliza la ejecución del programa
        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Procedimiento para restablecer entradas, resultados y variables internas
        private void ReiniciarControles()
        {
            txtEstudiante.Text = string.Empty;
            rdbMatutina.Checked = false;
            rdbVespertina.Checked = false;
            cmbAsignatura.SelectedIndex = -1;

            txtP1.Text = string.Empty;
            txtP2.Text = string.Empty;
            txtP3.Text = string.Empty;
            txtP4.Text = string.Empty;
            chkAsistencia.Checked = true;

            lstBoletin.Items.Clear();

            lblPromedioGeneral.Text = "0.00";
            lblAprobadas.Text = "0";
            lblRecuperacion.Text = "0";
            lblReprobadas.Text = "0";
            lblSituacion.Text = "Situación: -";

            acumuladorPromedios = 0.0;
            contadorMaterias = 0;
            materiasAprobadas = 0;
            materiasRecuperacion = 0;
            materiasReprobadas = 0;

            txtEstudiante.Focus();
        }
    }
}